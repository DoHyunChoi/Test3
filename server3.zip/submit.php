<?php
include "data.php";

$email = $_POST['email'];
$pw = $_POST['pw'];
$phone = $_POST['phone'];
$name = $_POST['name'];
$serial_num = $_POST['serial_num'];
$hash = password_hash($pw, PASSWORD_DEFAULT);

mysql_query("set session character_set_connection=utf8;");

mysql_query("set session character_set_results=utf8;");

mysql_query("set session character_set_client=utf8;");

$mysql = "INSERT INTO $board (name, email, pw, phone, serial_num) VALUES ('$name', '$email', '$pw', '$phone', '$serial_num')";
$result = mysql_query($mysql);
echo "성공적으로 가입되었습니다.";

?>  
