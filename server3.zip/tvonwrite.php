<? 
	include "d.php";

	$tvon = $_POST['tvon'];

	mysql_query("set session character_set_connection=utf8;");
	mysql_query("set session character_set_results=utf8;");
	mysql_query("set session character_set_client=utf8;");

	$mysql = "UPDATE $board SET tvon='$tvon'";
	$result = mysql_query($mysql);

	mysql_close($conn);

	echo $row['tvon'];
?>

