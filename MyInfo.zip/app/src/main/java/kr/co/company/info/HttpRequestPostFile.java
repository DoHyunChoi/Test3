package kr.co.company.info;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Dictionary;

public class HttpRequestPostFile implements Runnable{

	private final int COM = 1;
	private final int FAIL = 2;
	private String lineEnd = "\r\n";
	private String twoHyphens = "--";
	private String boundary = "*****";  
	public static final int ENCODER_TYPE_UTF8 	= 0;
	public static final int ENCODER_TYPE_EUCKR 	= 1;
	public static final int ENCODER_TYPE_MS949 	= 2;
	private String strUrl;
	private String encoderType;
	private String[] encoderTypes = {"utf-8", "euc-kr", "ms949"};
	private String[] keys;
	private String[] values;
	private String[] fileNames;
	private String[] fileKeys;
	private String filesPath;
	private HttpRequestPostFileListener listener;
	private Thread thread;
	private String element;
	private ArrayList<Dictionary> dicArray = new ArrayList<Dictionary>();

	/**
	 * @param strUrl URL주소
	 * @param encoderType 한글 인코딩 타입  예) HttpRequestPostFile.ENCODER_TYPE_UTF8, HttpRequestPostFile.ENCODER_TYPE_EUCKR, HttpRequestPostFile.ENCODER_TYPE_MS949
	 * @param keys 컨텐츠 파라미터 키값
	 * @param values 컨텐츠파라키터 값
	 * @param fileKeys 파일 키값
	 * @param fileNames 파일 이름
	 * @param filesPath 파일 경로
	 * @param listener 리스너
	 */
	public HttpRequestPostFile(String strUrl, int encoderType, String[] keys, String[] values
			, String[] fileKeys, String[] fileNames, String filesPath, HttpRequestPostFileListener listener, String element){
		this.strUrl = strUrl;
		this.encoderType = encoderTypes[encoderType];
		this.keys = keys;
		this.values = values;
		this.fileKeys = fileKeys;
		this.fileNames = fileNames;
		this.filesPath = filesPath;
		this.listener = listener;
		this.element = element;
		start();
	}
	
	public void start() {
		
		synchronized(this) {
			thread = new Thread(this);
			thread.start();
		}
	}
	
	public void stop() {
		synchronized(this) {
			thread.interrupt();
			thread = null;
		}
	}

	private Handler handler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case COM:
				listener.httpRequestComplete(dicArray);
				break;
			case FAIL:
				listener.httpRequestError();
				break;
			}
		};
	};


	public static String enCoder(String str, String type){
		String enStr = "";

		if(str == null)
			return enStr;

		try {
			enStr = java.net.URLEncoder.encode(new String(str.getBytes(type)));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return enStr;
	}

	private DataOutputStream initStreamDataContents(DataOutputStream dos)throws IOException{
		DataOutputStream out = dos;

		for(int i = 0; i < keys.length; i++){
			out.writeBytes(twoHyphens + boundary + lineEnd);
			out.writeBytes("Content-Disposition: form-data; name=\"" + keys[i] + "\""+ lineEnd);
			out.writeBytes(lineEnd);
			out.writeBytes(enCoder(values[i], encoderType));
			out.writeBytes(lineEnd);
		}

		return out;
	}

	public static boolean isEmpty(String str){
		if("".equals(str) || str == null){
			return true;
		}
		return false;
	}



	private DataOutputStream initStreamDataFiles(DataOutputStream dos)throws IOException{
		DataOutputStream out = dos;
		
		if(fileNames != null){
			
			for(int i = 0; i < fileNames.length; i++){
				if(isEmpty(fileNames[i])){
					continue;
				}
				out.writeBytes(twoHyphens + boundary + lineEnd);
				out.writeBytes("Content-Disposition: form-data; name=\"" + fileKeys[i] + "\"; filename=\"" + fileNames[i] + "\"" + lineEnd);
				out.writeBytes(lineEnd);
				FileInputStream input = null;
				try {
					input = new FileInputStream(filesPath + fileNames[i]);
					int bytesAvailable = input.available();
					int maxBufferSize = 1024;
					int bufferSize = Math.min(bytesAvailable, maxBufferSize);
					byte[] buffer = new byte[bufferSize];
					int bytesRead = input.read(buffer, 0, bufferSize);
					while(bytesRead > 0){
						out.write(buffer, 0, bufferSize);
						bytesAvailable = input.available();
						bufferSize = Math.min(bytesAvailable, maxBufferSize);
						bytesRead = input.read(buffer, 0, bufferSize);
					}
					input.close();
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					if(input != null){
						input.close();
						input = null;
					}
				}
				out.writeBytes(lineEnd);
				out.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
			}
		}
		return out;
	}

	@SuppressWarnings("resource")
	@Override
	public void run() {

		URL url = null;
		HttpURLConnection http = null;
		DataOutputStream dos = null;
		InputStreamReader input = null;

		try {
			url = new URL(strUrl); 
//			Log.d("URL", "URL : " + url.toString());
			http = (HttpURLConnection) url.openConnection();
			http.setDefaultUseCaches(false);                                            
			http.setDoOutput(true);   
			http.setDoInput(true);
			http.setRequestMethod("POST");          
			http.setRequestProperty("Connection", "Keep-Alive");
			http.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
			dos = new DataOutputStream(http.getOutputStream());
			dos = initStreamDataContents(dos);
			dos = initStreamDataFiles(dos);
			dos.flush();

			if(parsingData(http.getInputStream())){
				Message msg = Message.obtain(handler);
				msg.what = COM;
				handler.sendMessage(msg);
			}else{
				Message msg = Message.obtain(handler);
				msg.what = FAIL;
				handler.sendMessage(msg);
			}


		} catch (Exception e) {
			Message msg = Message.obtain(handler);
			msg.what = FAIL;
			handler.sendMessage(msg);
			e.printStackTrace();
		}finally{
			if(url != null){
				url = null;
			}
			if(http != null){
				http.disconnect();
				http = null;
			}
			if(dos != null){
				try {
					dos.close();
					dos = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(input != null){
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				input = null;
			}
		}
	}
	
	private boolean parsingData(InputStream in) {
		try {

			return true;
		}
		catch(Exception e) {
			e.printStackTrace();
			Log.d("HttpRequest","parsing Exception : "+e.toString());
			return false;
		}			
	}
	
	public interface HttpRequestPostFileListener{
		public void httpRequestComplete(ArrayList<Dictionary> dicArray);
		public void httpRequestError();
	}
}
