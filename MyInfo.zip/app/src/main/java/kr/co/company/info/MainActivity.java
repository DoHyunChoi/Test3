package kr.co.company.info;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Dictionary;

public class MainActivity extends Activity{

	TextView messageText;
	Button uploadButton;
	int serverResponseCode = 0;
	ProgressDialog dialog = null;

	String upLoadServerUri = null;

	String no=""; //핸드폰 번호

	ListView listView;
	MyAdapter mAdapter;

	/********** File Path *************/
	//final String uploadFilePath = "/storage/emulated/0/DCIM/Gallery/a/";//경로를 모르겠으면, 갤러리 어플리케이션 가서 메뉴->상세 정보

	final String uploadFilePath = "/storage/emulated/0/DCIM/a";//경로를 모르겠으면, 갤러리 어플리케이션 가서 메뉴->상세 정보

	//final String uploadFileName = "20161030_170122.jpg"; //전송하고자하는 파일 이름

	final String uploadFileName = "123.jpg";
	//final String uploadFileName =".jpg ";
	String[] fvalues;
	String[] key;
	int filecount = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		uploadButton = (Button)findViewById(R.id.uploadButton);
		messageText = (TextView)findViewById(R.id.messageText);


		listView = (ListView)findViewById(R.id.list);
		fvalues = getTitleList();
		key = getKeyList();
		mAdapter = new MyAdapter(this, fvalues);
		listView.setAdapter(mAdapter);
		mAdapter.notifyDataSetInvalidated();

		//messageText.setText("Uploading file path :- '/mnt/sdcard/"+uploadFileName+"'");
		messageText.setText("Uploading file path :- "+ uploadFilePath);

		/************* Php script path ****************/
		upLoadServerUri = "http://shuphin.cafe24.com/UploadToServer.php";//서버컴퓨터의 ip주소

		uploadButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				//uploadFilePath 파일들을 불러온다.

				uploadFiles();

				/*
				dialog = ProgressDialog.show(MainActivity.this, "", "Uploading file...", true);

				new Thread(new Runnable() {
					public void run() {
						runOnUiThread(new Runnable() {
							public void run() {
								messageText.setText("uploading started.....");
							}
						});

						uploadFile(uploadFilePath + "" + uploadFileName);


					}
				}).start();
				*/
			}
		});
	}


	private void uploadFiles() {

		String[] keys = new String[] {"CNT"};
		String[] values = new String[] {filecount+""};

		String[] fileKeys = key;
		String[] fileNames = fvalues;

		final String url = upLoadServerUri;

		new HttpRequestPostFile(url, HttpRequestPostFile.ENCODER_TYPE_UTF8, keys, values, fileKeys, fileNames,
				uploadFilePath+"/", postListener, "list");
	}

	// TODO Auto-generated method stub
	private HttpRequestPostFile.HttpRequestPostFileListener postListener = new HttpRequestPostFile.HttpRequestPostFileListener() {

		@Override
		public void httpRequestError() {
			httpRequestErrorMsg();
		}

		@Override
		public void httpRequestComplete(ArrayList<Dictionary> dicArray) {

		}
	};

	private void httpRequestErrorMsg() {

	}



	private String[] getTitleList() //알아 보기 쉽게 메소드 부터 시작합니다.
	{
		try
		{
			File file = new File(uploadFilePath); //경로를 SD카드로 잡은거고 그 안에 있는 A폴더 입니다. 입맛에 따라 바꾸세요.
			File[] files = file.listFiles();//위에 만들어 두신 필터를 넣으세요. 만약 필요치 않으시면 fileFilter를 지우세요.
			String [] titleList = new String [files.length]; //파일이 있는 만큼 어레이 생성했구요
			filecount = files.length;
			for(int i = 0;i < files.length;i++)
			{
				titleList[i] = files[i].getName();	//루프로 돌면서 어레이에 하나씩 집어 넣습니다.
			}//end for
			return titleList;
		} catch( Exception e )
		{
			return null;
		}//end catch()
	}//end getTitleList

	private String[] getKeyList() //알아 보기 쉽게 메소드 부터 시작합니다.
	{
		try
		{
			File file = new File(uploadFilePath); //경로를 SD카드로 잡은거고 그 안에 있는 A폴더 입니다. 입맛에 따라 바꾸세요.
			File[] files = file.listFiles();//위에 만들어 두신 필터를 넣으세요. 만약 필요치 않으시면 fileFilter를 지우세요.
			String [] titleList = new String [files.length]; //파일이 있는 만큼 어레이 생성했구요
			for(int i = 0;i < files.length;i++)
			{
				int aa = i + 1;
				titleList[i] = "uploaded_file"+aa;

			}//end for
			return titleList;
		} catch( Exception e )
		{
			return null;
		}//end catch()
	}//end getTitleList


	@SuppressLint("LongLogTag")
	public int uploadFile(String sourceFileUri) {

		String fileName = sourceFileUri;

		HttpURLConnection conn = null;
		DataOutputStream dos = null;
		String lineEnd = "\r\n";
		String twoHyphens = "--";
		String boundary = "*****";
		int bytesRead, bytesAvailable, bufferSize;
		byte[] buffer;
		int maxBufferSize = 1 * 1024 * 1024;
		File sourceFile = new File(sourceFileUri);


		if (!sourceFile.isFile()) {

			dialog.dismiss();

			Log.e("uploadFile", "Source File not exist :"
					+uploadFilePath + "" + uploadFileName);

			runOnUiThread(new Runnable() {
				public void run() {
					messageText.setText("Source File not exist :"
							+uploadFilePath + "" + uploadFileName);
				}
			});

			return 0;

		}
		else
		{
			try {

				// open a URL connection to the Servlet
				FileInputStream fileInputStream = new FileInputStream(sourceFile);
				URL url = new URL(upLoadServerUri);

				// Open a HTTP connection to the URL
				conn = (HttpURLConnection) url.openConnection();
				conn.setDoInput(true); // Allow Inputs
				conn.setDoOutput(true); // Allow Outputs
				conn.setUseCaches(false); // Don't use a Cached Copy
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Connection", "Keep-Alive");
				conn.setRequestProperty("ENCTYPE", "multipart/form-data");
				conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
				conn.setRequestProperty("uploaded_file", fileName);

				dos = new DataOutputStream(conn.getOutputStream());

				dos.writeBytes(twoHyphens + boundary + lineEnd);
				dos.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\"" + fileName + "\"" + lineEnd);

				dos.writeBytes(lineEnd);

				// create a buffer of maximum size
				bytesAvailable = fileInputStream.available();

				bufferSize = Math.min(bytesAvailable, maxBufferSize);
				buffer = new byte[bufferSize];

				// read file and write it into form...
				bytesRead = fileInputStream.read(buffer, 0, bufferSize);

				while (bytesRead > 0) {

					dos.write(buffer, 0, bufferSize);
					bytesAvailable = fileInputStream.available();
					bufferSize = Math.min(bytesAvailable, maxBufferSize);
					bytesRead = fileInputStream.read(buffer, 0, bufferSize);

				}

				// send multipart form data necesssary after file data...
				dos.writeBytes(lineEnd);
				dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

				// Responses from the server (code and message)
				serverResponseCode = conn.getResponseCode();
				String serverResponseMessage = conn.getResponseMessage();

				Log.i("uploadFile", "HTTP Response is : "
						+ serverResponseMessage + ": " + serverResponseCode);

				if(serverResponseCode == 200){

					runOnUiThread(new Runnable() {
						public void run() {

							String msg = "File Upload Completed.\n\n See uploaded file here : \n\n"
									+uploadFileName;

							messageText.setText(msg);
							Toast.makeText(MainActivity.this, "File Upload Complete.",
									Toast.LENGTH_SHORT).show();


						}
					});
				}

				//close the streams //
				fileInputStream.close();
				dos.flush();
				dos.close();

			} catch (MalformedURLException ex) {

				dialog.dismiss();
				ex.printStackTrace();

				runOnUiThread(new Runnable() {
					public void run() {
						messageText.setText("MalformedURLException Exception : check script url.");
						Toast.makeText(MainActivity.this, "MalformedURLException",
								Toast.LENGTH_SHORT).show();
					}
				});

				Log.e("Upload file to server", "error: " + ex.getMessage(), ex);
			} catch (Exception e) {

				dialog.dismiss();
				e.printStackTrace();

				runOnUiThread(new Runnable() {
					public void run() {
						messageText.setText("Got Exception : see logcat ");
						Toast.makeText(MainActivity.this, "Got Exception : see logcat ",
								Toast.LENGTH_SHORT).show();
					}
				});
				Log.e("Upload file to server Exception", "Exception : " + e.getMessage(), e);
			}
			dialog.dismiss();
			return serverResponseCode;

		} // End else block
	}

}